from django.apps import AppConfig


class UploadformConfig(AppConfig):
    name = 'uploadForm'
